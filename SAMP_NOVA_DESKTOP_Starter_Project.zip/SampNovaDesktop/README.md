# SAMP NOVA DESKTOP — Android starter

Version: 0.1.0  
Package: `com.sampnova.desktop`

## Included in this first foundation
- Dark SAMP NOVA launcher dashboard
- Desktop workspace preview
- Starter SA-MP keyboard/mouse mapping profile screen
- Android Storage Access Framework file picker for selecting a modpack
- Optional launch handoff to an installed Winlator package (if present)

## Build
Open this folder in Android Studio (Giraffe or newer), allow Gradle sync, then Build > Build APK(s).

Requirements:
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 (downloaded by Android Studio/Gradle)

## Important limitations
This is source code for the first app foundation, not a finished APK.
- Selecting a modpack does not install it. Mod formats and target SA-MP client paths must be identified before a safe installer can be implemented.
- Android apps cannot arbitrarily inject keyboard/mouse events into every other app. True cross-app mapping needs game-native support or a carefully designed, user-enabled accessibility/overlay approach, subject to Android version and game compatibility.
- An Android SA-MP APK does not become a Windows PC game just by importing it. The Windows environment is a separate x86/Windows compatibility layer (for example Winlator), and performance/compatibility depend on the device and game.
- Chatbox replacement and desktop-like multi-window behavior depend on the target SA-MP client and cannot be guaranteed universally.

## Next development stages
1. Test the launcher on the target Android phone.
2. Identify the exact SA-MP APK/client and Android version.
3. Implement persistent editable control profiles.
4. Add a permissions-based overlay and test hardware keyboard/mouse behavior.
5. Build modpack validation and client-specific installation/backup.
6. Add Windows environment handoff and per-game configuration.
