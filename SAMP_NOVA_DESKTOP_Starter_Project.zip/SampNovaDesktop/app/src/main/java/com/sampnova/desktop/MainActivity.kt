package com.sampnova.desktop

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 11, 18)
    private val panel = Color.rgb(19, 25, 38)
    private val accent = Color.rgb(65, 197, 245)
    private val muted = Color.rgb(153, 169, 190)
    private var importedName = "No modpack imported"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(18))
            setBackgroundColor(bg)
        }
    }

    private fun heading(root: LinearLayout, title: String, subtitle: String) {
        root.addView(TextView(this).apply {
            text = title
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = subtitle
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(5), 0, dp(18))
        })
    }

    private fun card(root: LinearLayout, title: String, detail: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(panel, 18)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        })
        box.addView(TextView(this).apply {
            text = detail
            textSize = 12f
            setTextColor(muted)
            setPadding(0, dp(5), 0, 0)
        })
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(11)
        root.addView(box, lp)
    }

    private fun button(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(28, 111, 153), 14)
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(9) })
    }

    private fun showHome() {
        val root = baseLayout()
        heading(root, "SAMP NOVA", "DESKTOP  •  MOBILE-TO-PC GAMING SHELL")
        val status = TextView(this).apply {
            text = "PROJECT BUILD 0.1.0     •     ANDROID"
            textSize = 10f
            letterSpacing = 0.12f
            setTextColor(accent)
            setPadding(0, 0, 0, dp(14))
        }
        root.addView(status)
        card(root, "DESKTOP MODE", "Windows-inspired home, app shortcuts and desktop workspace") { showDesktop() }
        card(root, "KEYBOARD & MOUSE", "Configure SA-MP control profiles and key assignments") { showControls() }
        card(root, "MODPACK MANAGER", importedName) { pickModpack() }
        card(root, "WINDOWS ENVIRONMENT", "Open a compatible installed Windows environment such as Winlator") { openWindowsEnvironment() }
        card(root, "SA-MP LAUNCHER", "Choose an installed compatible SA-MP client") { showLauncherInfo() }
        root.addView(TextView(this).apply {
            text = "NOTE: This is the first app foundation. Cross-app input mapping, Windows emulation and safe mod installation require separate compatibility and permission work."
            textSize = 11f
            setTextColor(muted)
            setPadding(2, dp(10), 2, 0)
        })
        setContentView(root)
    }

    private fun showDesktop() {
        val root = baseLayout()
        heading(root, "NOVA DESKTOP", "Desktop workspace preview")
        val desktop = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(15, 34, 54), 22)
            setPadding(dp(12), dp(35), dp(12), dp(35))
        }
        desktop.addView(TextView(this).apply {
            text = "SAMP NOVA"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        desktop.addView(TextView(this).apply {
            text = "DESKTOP WORKSPACE"
            textSize = 11f
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(22))
        })
        desktop.addView(TextView(this).apply {
            text = "This workspace is the launcher shell. True multi-window behavior and a system-wide mouse overlay are planned for later compatibility stages."
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        root.addView(desktop, LinearLayout.LayoutParams(-1, 0, 1f))
        button(root, "BACK TO NOVA HOME") { showHome() }
        setContentView(root)
    }

    private fun showControls() {
        val root = baseLayout()
        heading(root, "CONTROL MAPPING", "Default SA-MP keyboard profile • editable prototype")
        val rows = listOf(
            "W / A / S / D" to "Move forward / left / backward / right",
            "SPACE" to "Jump",
            "SHIFT" to "Sprint",
            "F" to "Enter / exit vehicle (server dependent)",
            "H" to "Vehicle interaction (server dependent)",
            "ENTER" to "Open chat / send message",
            "ESC" to "Close menu / pause (client dependent)",
            "MOUSE LEFT" to "Primary action",
            "MOUSE RIGHT" to "Aim / secondary action",
            "MOUSE WHEEL" to "Weapon / item cycle"
        )
        rows.forEach { (key, desc) ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = rounded(panel, 12)
            }
            line.addView(TextView(this).apply {
                text = key
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(accent)
            }, LinearLayout.LayoutParams(dp(118), -2))
            line.addView(TextView(this).apply {
                text = desc
                textSize = 12f
                setTextColor(Color.WHITE)
            })
            root.addView(line, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
        root.addView(TextView(this).apply {
            text = "Mapping list is a starter profile, not yet an input injector. Actual cross-app remapping needs an approved accessibility/overlay design or native game support."
            textSize = 11f
            setTextColor(muted)
            setPadding(2, dp(12), 2, dp(12))
        })
        button(root, "BACK") { showHome() }
        setContentView(root)
    }

    private fun pickModpack() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, 410)
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility in this starter.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 410 && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                importedName = "Selected: ${uri.lastPathSegment ?: "modpack file"}"
                Toast.makeText(this, "File selected. It has not been installed or applied.", Toast.LENGTH_LONG).show()
                showHome()
            }
        }
    }

    private fun openWindowsEnvironment() {
        val candidates = listOf("com.winlator", "com.winlator.cmod")
        val launch = candidates.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "No supported Winlator installation detected. Install and configure a compatible Windows environment separately.", Toast.LENGTH_LONG).show()
    }

    private fun showLauncherInfo() {
        val root = baseLayout()
        heading(root, "SA-MP CLIENT", "Client compatibility")
        root.addView(TextView(this).apply {
            text = "Android SA-MP clients use different packages, files and input behavior. This starter does not automatically modify or inject into another APK. Next stage: add a user-selected installed client, test launch compatibility, then build a safe per-client profile."
            textSize = 14f
            setTextColor(Color.WHITE)
        })
        button(root, "BACK") { showHome() }
        setContentView(root)
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
